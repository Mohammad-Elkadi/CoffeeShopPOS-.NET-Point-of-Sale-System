﻿
using CountriesCurrencyBusinessLayer;
using Microsoft.VisualBasic;
using OrderBusinessAccessLayer;
using ProductsBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CoffeShopPresentationLayer
{
    public partial class AdminControlPresentation : Form
    {
        private DataGridView dgvProductsInfo = new DataGridView();
        private DataGridView dgvOrdersInfo = new DataGridView();

        static int pd = 0;
        static int currentOrderID = 0; // keep track of active order




        private Button activeButton = null;
        private Panel cardPanel;
        private Panel storeInfoPanel;
        private Button btnAddNewProduct;
        private FlowLayoutPanel flowProducts;
        private FlowLayoutPanel flowProducts2;
        private Button btnViewOrderinOrderContainer;

        private Button btnBackfromDgvtoOrderContainer;
        private Button btnPlaceOrder;
        private Button btnGofromMenuToDgv;
        private Button btnBackFromOrderContainertoMenu;
        private Button btnGotoMenyfromDgv;


        private Panel storeInformationContainer;
        private Panel taxSettingsContainer;
        private Panel OrderContainer;
        private DataTable dtOrders;



        static float totallyPrice = 1;
        private List<Panel> panel1 = new List<Panel>();
        private List<Panel> panel2 = new List<Panel>();



        public AdminControlPresentation()
        {
            InitializeComponent();
            InitializeOrdersGrid();
            if (flowProducts2 != null)
            {
                btnBackFromOrderContainertoMenu.Visible = false;
                btnGotoMenyfromDgv.Visible = false;


            }

            _StyleButton();

        }
        private void InitializeOrdersGrid()
        {
            if (!this.Controls.Contains(dgvOrdersInfo))
            {
                dgvOrdersInfo.Location = new Point(263, 226);
                dgvOrdersInfo.Size = new Size(1050, 380);
                dgvOrdersInfo.Visible = false; // hide initially
                dgvOrdersInfo.BorderStyle = BorderStyle.None;
                dgvOrdersInfo.BackgroundColor = Color.White;
                dgvOrdersInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgvOrdersInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dgvOrdersInfo.MultiSelect = false;
                dgvOrdersInfo.ReadOnly = true;

                this.Controls.Add(dgvOrdersInfo);
            }

            DesignOrdersGrid();
        }

        private void _StyleButton()
        {
            StyleButton(btnNewOrder);
            StyleButton(btnMenu);
            StyleButton(btnDashboard);
            StyleButton(btnStaff);
            StyleButton(btnSettings);
            StyleButton(btnInventory);
            StyleButton(btnReports);


        }

        private void AdminControlPresentation_Load(object sender, EventArgs e)
        {



        }


        private void createProductsTable()
        {
            // Set properties
            dgvProductsInfo.Location = new Point(263, 226);
            dgvProductsInfo.Size = new Size(1050, 380);
            dgvProductsInfo.Visible = true; // make it visible when inventory clicked
            dgvProductsInfo.BorderStyle = BorderStyle.None;
            dgvProductsInfo.BackgroundColor = Color.White;
            dgvProductsInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvProductsInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductsInfo.MultiSelect = false;
            dgvProductsInfo.ReadOnly = true;

            // Add to form if not already added
            if (!this.Controls.Contains(dgvProductsInfo))
            {
                this.Controls.Add(dgvProductsInfo);
            }

            // Apply your column styling
            DesignProductsGrid();
        }

        private void StyleButton(Button btn)
        {


            // Base style
            btn.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            btn.ForeColor = Color.Black;
            btn.BackColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;

            btn.Padding = new Padding(10, 0, 0, 0);
            btn.Cursor = Cursors.Hand;

            // Hover effect
            btn.MouseEnter += (s, e) =>
            {
                if (btn != activeButton) // Only apply hover if not active
                    btn.BackColor = Color.LightGray;
            };
            btn.MouseLeave += (s, e) =>
            {
                if (btn != activeButton) // Reset to base if not active
                    btn.BackColor = Color.White;
            };

            // Click effect
            btn.Click += (s, e) =>
            {
                if (activeButton != null)
                {
                    // Reset previous active button
                    activeButton.BackColor = Color.White;
                    activeButton.ForeColor = Color.Black;
                }

                // Set this button as active
                activeButton = btn;
                activeButton.BackColor = Color.Black;
                activeButton.ForeColor = Color.White;
            };

        }





        private void button1_Click(object sender, EventArgs e)
        {
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = false;

            }
            if (taxSettingsContainer != null)
            {
                taxSettingsContainer.Visible = false;

            }
            if (dgvOrdersInfo!= null)
            {
                dgvOrdersInfo.Visible = false;
                
            }
            if (OrderContainer!=null)
            {
                OrderContainer.Visible = false;
                
            }
            if (flowProducts !=null)
            {
                flowProducts.Visible = false;
                
            }
            if (flowProducts2!=null)
            {
                 flowProducts2.Visible = false;
                
            }
            lnlBtnStatus.Visible = true;
            lblButtonTiltle.Visible = true;
            lblButtonTiltle.Text = "Dashboard";
            lnlBtnStatus.Text = "Overview of your store performance\r\n\r\n";

            if (btnAddNewProduct != null)
            {
                btnAddNewProduct.Visible = false;

            }

        }

        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            if (btnAddNewProduct!=null)
            {
                btnAddNewProduct.Visible = false;
                
            }
            if (flowProducts2 != null)
            {
                flowProducts2.Visible = true;

            }

            if (taxSettingsContainer != null)
            {
                taxSettingsContainer.Visible = false;

            }
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = false;

            }
            if (flowProducts != null)
            {
                flowProducts.Visible = false;

            }
            if (btnAddNewProduct != null)
            {
                btnAddNewProduct.Visible = false;

            }
            dgvProductsInfo.Visible = false;

            lblButtonTiltle.Visible = true;
            lnlBtnStatus.Visible = true;

            lblButtonTiltle.Text = "New Order";
            lnlBtnStatus.Text = "Select products to add to order";
            SetupFlowLayoutPanel2();
            panel2.Clear();
            float priceinLBP;
            btnPlaceOrder = CreateModernButton("🚀☕ Place Order", "Black", 950, 650, 170, 40);


            int[] IDs = clsProductsBusinessLayer.GetProductsByArray();
            int productsNb = IDs.Length;
            for (int i = 0; i < productsNb; i++)

            {
                Panel card = CreateCardPanel(0, 0, 200, 230);
                pd = IDs[i];
                var productInfo = clsProductsBusinessLayer.GetProducInfotByID(pd);


                Label lbl = new Label()
                {

                    Text = productInfo.ProductName,
                    Location = new Point(8, 10),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 11, FontStyle.Bold),
                    ForeColor = Color.Black


                };
                card.Controls.Add(lbl);

                Label lblCategory = new Label()
                {
                    Text = productInfo.CategoryName,
                    Location = new Point(8, 35),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),
                    ForeColor = Color.Black



                };
                card.Controls.Add(lblCategory);


                Label lblDescription = new Label()
                {
                    Text = productInfo.desc,
                    Location = new Point(8, 80),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),


                    ForeColor = Color.Gray
                };
                card.Controls.Add(lblDescription);


                float price = productInfo.productPrice;
                priceinLBP = price * 85;
                Label lblPrice = new Label();
                lblPrice.Text = "$" + price.ToString() + "\n" +
                 "LBP " + priceinLBP.ToString() + "000";

                lblPrice.Font = new Font("Segoe UI", 11, FontStyle.Bold);
                lblPrice.ForeColor = Color.Black;
                lblPrice.Location = new Point(8, 105);
                lblPrice.AutoSize = true;
                card.Controls.Add(lblPrice);




                Button btnAddToOrder = CreateModernButton("  Add  ", "Black", 10, 160, 170, 50);

                btnAddToOrder.MouseLeave += (s, e) =>
                {
                    btnAddToOrder.BackColor = Color.Black;
                    btnAddToOrder.ForeColor = Color.White;
                };

                string productNameCopy = productInfo.ProductName;
                string descCopy = productInfo.desc;
                float priceCopy = priceinLBP;
                int productIDCopy = productInfo.ProductID;



                btnAddToOrder.Click += (s, e) =>
                {
                    flowProducts2.Visible = false;

                    string productName = lbl.Text;
                    string description = lblDescription.Text;
                    if (currentOrderID == 0)
                    {
                        currentOrderID = AddNewOrder(DateTime.Now, 0, "");
                        MessageBox.Show($"New order created: #{currentOrderID}");
                    }






                    CreateOrderView(productIDCopy, productNameCopy, priceCopy, descCopy);
                    if (currentOrderID != 0 && flowProducts2.Visible == false && OrderContainer.Visible == false)
                    {

                        btnGofromMenuToDgv = CreateModernButton("View Order ", "Black", 140, 600, 120, 50);
                        btnGofromMenuToDgv.Visible = true;
                        btnGofromMenuToDgv.Click += (s, e) =>
                        {
                            dgvOrdersInfo.Visible = true;
                            OrderContainer.Visible = false;
                            flowProducts2.Visible = false;
                            btnPlaceOrder.Visible = true;
                            PlaceOrder("");
                        };
                        this.Controls.Add(btnGofromMenuToDgv);


                    }







                };

                card.Controls.Add(btnAddToOrder);


                panel2.Add(card);
                flowProducts2.Controls.Add(card);




            }

        }


        private void CreateOrderView(int product_id, string productName, float price, string desc)
        {
            int quantity = 1;
            DateTime date = new DateTime();

            OrderContainer = CreateCardPanel(280, 170, 950, 520);

            Label lblOrder = new Label();
            lblOrder.Text = "Current Order:" + currentOrderID.ToString();
            lblOrder.AutoSize = true;
            lblOrder.Location = new Point(25, 20);
            lblOrder.Font = new Font("Segoe UI", 14, FontStyle.Bold);
            lblOrder.ForeColor = Color.Black;
            OrderContainer.Controls.Add(lblOrder);

            // Product name
            Label lblProductName = new Label();
            lblProductName.Text = productName;  // use parameter directly
            lblProductName.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            lblProductName.ForeColor = Color.Black;
            lblProductName.Location = new Point(25, 100);
            OrderContainer.Controls.Add(lblProductName);

            // Description
            Label lblDescription = new Label();
            lblDescription.Text = desc;
            lblDescription.Font = new Font("Segoe UI", 10);
            lblDescription.ForeColor = Color.Gray;
            lblDescription.Location = new Point(25, 130);
            lblDescription.AutoSize = true;
            OrderContainer.Controls.Add(lblDescription);

            // Price (LBP)
            Label lblPrice = new Label();
            lblPrice.AutoSize = true;
            lblPrice.Text = $"Price: LBP {price.ToString("N0")}" + "000";

            lblPrice.ForeColor = Color.Black;
            lblPrice.Location = new Point(25, 205);
            lblPrice.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            OrderContainer.Controls.Add(lblPrice);

            // Quantity label
            Label lblAmount = new Label();
            lblAmount.AutoSize = true;
            lblAmount.Text = quantity.ToString();
            lblAmount.Location = new Point(480, 205);
            lblAmount.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblAmount.ForeColor = Color.Black;
            OrderContainer.Controls.Add(lblAmount);

            // Total label
            Label lblTotalPrice = new Label();
            lblTotalPrice.AutoSize = true;
            float totalPrice = price * quantity;

            lblTotalPrice.Text = $"Total: LBP {totalPrice.ToString("N0")}" + "000";
            lblTotalPrice.Location = new Point(745, 205);
            lblTotalPrice.Font = new Font("Lato", 11, FontStyle.Bold);
            lblTotalPrice.ForeColor = Color.DarkGreen;
            OrderContainer.Controls.Add(lblTotalPrice);


            Label lblNote = new Label();
            lblNote.AutoSize = true;
            lblNote.Text = "Notes:";
            lblNote.Location = new Point(25, 280);
            lblNote.ForeColor = Color.Black;
            lblTotalPrice.Font = new Font("Lato", 13, FontStyle.Bold);
            OrderContainer.Controls.Add(lblNote);

            TextBox txtNotes = CreateSettingTextbox("Add a Note for an order", 240);
            txtNotes.Location = new Point(80, 300);
            OrderContainer.Controls.Add(txtNotes);

            // + Button
            Button btnAdd = CreateModernButton("+", "Black", 420, 200, 45, 45);
            btnAdd.Click += (s, e) =>
            {
                quantity++;
                lblAmount.Text = quantity.ToString();
                lblTotalPrice.Text = $"Total: LBP " + (quantity * price).ToString() + "000";
            };
            OrderContainer.Controls.Add(btnAdd);


            // - Button
            Button btnRemove = CreateModernButton("-", "Black", 515, 200, 45, 45);
            btnRemove.BackColor = Color.Black;
            btnRemove.AutoSize = true;
            btnRemove.ForeColor = Color.White;

            btnRemove.Click += (s, e) =>
            {

                if (quantity > 0) quantity--;
                lblAmount.Text = quantity.ToString();
                lblTotalPrice.Text = $"Total: LBP " + (quantity * price).ToString() + "000";
            };
            OrderContainer.Controls.Add(btnRemove);

            // Button btnConfirm = CreateModernButton("🚀☕ Place Order", "Black", 750, 450, 170, 40);
            Button btnCancel = CreateModernButton("❌☕ Cancel Order", "Black", 270, 450, 170, 40);
            Button btnAddtoOrder = CreateModernButton("+☕ Add to Order", "Black", 570, 450, 170, 40);

            Button btnViewOrderInTable = CreateModernButton("☕ View Order Table", "Black", 750, 450, 170, 40);


            OrderContainer.Controls.Add(btnViewOrderInTable);

            OrderContainer.Controls.Add(btnCancel);
            OrderContainer.Controls.Add(btnAddtoOrder);
            btnBackFromOrderContainertoMenu = CreateModernButton("Back to menu", "Black", 70, 450, 170, 40);
            btnBackFromOrderContainertoMenu.Click += (s, e) =>
            {
                OrderContainer.Visible = false;
                flowProducts2.Visible = true;
            };
            OrderContainer.Controls.Add(btnBackFromOrderContainertoMenu);

            btnViewOrderInTable.Click += (s, e) =>
            {
                if (dtOrders == null)
                    InitializeOrdersDataTable();

                dgvOrdersInfo.DataSource = dtOrders;
                dgvOrdersInfo.Visible = true;
                OrderContainer.Visible = false;
                dgvOrdersInfo.BringToFront();
                PlaceOrder(txtNotes.Text);
                if (dgvOrdersInfo.Visible == true)
                {
                    btnBackfromDgvtoOrderContainer = CreateModernButton("<= Back to order ", "Black", 270, 600, 120, 50);
                    btnBackfromDgvtoOrderContainer.Click += (s, e) =>
                    {
                        OrderContainer.Visible = true;
                        dgvOrdersInfo.Visible = false;
                        btnBackfromDgvtoOrderContainer.Visible = false;


                    };
                    btnGofromMenuToDgv = CreateModernButton("<= Back to menu ", "Black", 400, 600, 120, 50);

                    btnGofromMenuToDgv.Click += (s, e) =>
                    {
                        OrderContainer.Visible = false;
                        flowProducts2.Visible = true;
                        dgvOrdersInfo.Visible = false;
                    };



                }
                this.Controls.Add(btnBackfromDgvtoOrderContainer);
                this.Controls.Add(btnGofromMenuToDgv);

            };


            btnCancel.Click += (s, e) =>
            {
                DialogResult result = MessageBox.Show("Are you sure you want to cancel this order?", "Cancel Order", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    OrderContainer.Visible = false;
                    flowProducts2.Visible = true;
                    ResetCurrentOrder(); // ✅ clear current order
                    MessageBox.Show("Order canceled successfully.");
                }
            };


            btnAddtoOrder.Click += (s, e) =>
            {
                if (dtOrders == null)
                    InitializeOrdersDataTable();

                if (AddtoSameOrder(currentOrderID, product_id, price, quantity) > 0)
                {
                    MessageBox.Show("Product has been added to order");
                    dgvOrdersInfo.CellClick += dgvOrdersInfo_CellClick;

                    // Add product to DataTable
                    AddOrderToTable(product_id, productName, desc, quantity, price);


                    // Bind DataTable to DataGridView
                    DesignOrdersGrid();           // Keep the design intact
                    dgvOrdersInfo.DataSource = dtOrders;
                    dgvOrdersInfo.Refresh();
                }

                OrderContainer.Visible = false;
                flowProducts2.Visible = true;
            };



            this.Controls.Add(OrderContainer);

            OrderContainer.BringToFront();
        }
        private void AddOrderToTable(int product_id, string productName, string desc, int quantity, float price)
        {
            DataRow row = dtOrders.NewRow();
            row["product_id"] = product_id;
            row["product_name"] = productName;
            row["description"] = desc;
            row["quantity"] = quantity;
            row["unit_price"] = price;
            row["total"] = price * quantity;

            dtOrders.Rows.Add(row);
        }
        private bool UpdateO(int id, float p, string notes)
        {
            return clsOrderBusinessLayer.UpdateOrder(id, p, notes);
        }
        private int AddNewOrder(DateTime date, float price, string note)
        {
            int orderID = clsOrderBusinessLayer._AddNewOrder(DateTime.Now, "", 0, "Cash", 1);

            return orderID;

        }

        private int AddtoSameOrder(int order_id, int product_id, float unit_price, int quantity)
        {

            return clsOrderBusinessLayer._addToOrderItems(order_id, product_id, unit_price, quantity);
        }

        private void PlaceOrder(string notes)
        {
            btnPlaceOrder = CreateModernButton("🚀☕ Place Order", "Black", 950, 600, 170, 40);
            btnPlaceOrder.Click += (s, e) =>
            {
                if (dtOrders.Rows.Count == 0)
                {
                    MessageBox.Show("No items in the order!");
                    return;
                }

                // Calculate total price
                float totalPrice = 0;
                foreach (DataRow row in dtOrders.Rows)
                {
                    totalPrice += Convert.ToSingle(row["total"]);
                }

                if (UpdateO(currentOrderID, totalPrice, notes)) // You might want to add notes functionality
                {
                    MessageBox.Show($"Order has been placed successfully! with price LBP {totalPrice}" + "000");
                    ResetCurrentOrder();
                    dgvOrdersInfo.DataSource = null;
                    dgvOrdersInfo.Visible = false;
                    dtOrders.Clear(); // Clear the data table
                    btnPlaceOrder.Visible = false; // Hide the button after order is placed
                    flowProducts2.Visible = true; // Show products again
                }
                else
                {
                    MessageBox.Show("Failed to place order. Please try again.");
                }
            };

            this.Controls.Add(btnPlaceOrder);



        }

        private void ResetCurrentOrder()
        {
            currentOrderID = 0;
        }
        private void InitializeOrdersDataTable()
        {
            if (dtOrders != null) return; // Already initialized

            dtOrders = new DataTable();
            dtOrders.Columns.Add("product_id", typeof(int));
            dtOrders.Columns.Add("product_name", typeof(string));
            dtOrders.Columns.Add("description", typeof(string));
            dtOrders.Columns.Add("quantity", typeof(int));
            dtOrders.Columns.Add("unit_price", typeof(float));
            dtOrders.Columns.Add("total", typeof(float));
        }




        private void DesignOrdersGrid()
        {
            dgvOrdersInfo.Columns.Clear();
            dgvOrdersInfo.AutoGenerateColumns = false;
            dgvOrdersInfo.AllowUserToAddRows = false;
            dgvOrdersInfo.AllowUserToDeleteRows = false;
            dgvOrdersInfo.AllowUserToResizeRows = false;
            dgvOrdersInfo.RowHeadersVisible = false;
            dgvOrdersInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvOrdersInfo.MultiSelect = false;
            dgvOrdersInfo.BorderStyle = BorderStyle.None;
            dgvOrdersInfo.BackgroundColor = Color.White;
            dgvOrdersInfo.GridColor = Color.FromArgb(240, 240, 240);
            dgvOrdersInfo.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvOrdersInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Header style
            dgvOrdersInfo.EnableHeadersVisualStyles = false;
            dgvOrdersInfo.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvOrdersInfo.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
            dgvOrdersInfo.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvOrdersInfo.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvOrdersInfo.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            // Row style
            dgvOrdersInfo.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgvOrdersInfo.DefaultCellStyle.ForeColor = Color.Black;
            dgvOrdersInfo.DefaultCellStyle.BackColor = Color.White;
            dgvOrdersInfo.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(249, 250, 251);
            dgvOrdersInfo.DefaultCellStyle.SelectionBackColor = Color.FromArgb(243, 245, 247);
            dgvOrdersInfo.DefaultCellStyle.SelectionForeColor = Color.Black;
            dgvOrdersInfo.RowTemplate.Height = 36;



            // Columns
            dgvOrdersInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                Name = "product_id",
                DataPropertyName = "product_id",
                Visible = false
            });

            dgvOrdersInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Product Name",
                DataPropertyName = "product_name",
                FillWeight = 50,
                ReadOnly = true,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            });

            dgvOrdersInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Description",
                DataPropertyName = "description",
                FillWeight = 70,
                ReadOnly = true,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            });

            dgvOrdersInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Quantity",
                DataPropertyName = "quantity",
                Name = "quantity",
                ReadOnly = false,// ← THIS is the actual column name you should use

                FillWeight = 25,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter }
            });

            dgvOrdersInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Price (LBP)",
                DataPropertyName = "unit_price",
                FillWeight = 50,
                ReadOnly = true,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter }
            });

            dgvOrdersInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Total",
                DataPropertyName = "total",
                FillWeight = 105,
                ReadOnly = true,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter }
            });


            var editBtn = new DataGridViewButtonColumn()
            {
                HeaderText = "Edit",
                Text = "✏️ Edit",
                UseColumnTextForButtonValue = true,
                Width = 60,
                FlatStyle = FlatStyle.Popup,
                Name = "Edit"
            };
            dgvOrdersInfo.Columns.Add(editBtn);

            // Delete button
            var deleteBtn = new DataGridViewButtonColumn()
            {
                HeaderText = "Delete",
                Text = "🗑️ Delete",
                UseColumnTextForButtonValue = true,
                Width = 60,
                FlatStyle = FlatStyle.Popup,
                Name = "Delete"
            };
            dgvOrdersInfo.Columns.Add(deleteBtn);

            // Optional padding
            dgvOrdersInfo.CellPainting += (s, e) =>
            {
                if (e.RowIndex >= 0)
                    e.CellStyle.Padding = new Padding(8, 6, 8, 6);
            };






        }

        private void CreateOrdersDataTable()
        {
            dgvOrdersInfo.Location = new Point(263, 226);
            dgvOrdersInfo.Size = new Size(1050, 380);
            dgvOrdersInfo.Visible = true; // make it visible when inventory clicked
            dgvOrdersInfo.BorderStyle = BorderStyle.None;
            dgvOrdersInfo.BackgroundColor = Color.White;
            dgvOrdersInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrdersInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvOrdersInfo.MultiSelect = false;
            dgvOrdersInfo.ReadOnly = true;

            // Add to form if not already added
            if (!this.Controls.Contains(dgvOrdersInfo))
            {
                this.Controls.Add(dgvOrdersInfo);
            }

            // Apply your column styling
            DesignOrdersGrid();
        }






        private void _RefreshProductsList()
        {
            dgvProductsInfo.AutoGenerateColumns = true;
            DesignProductsGrid();

            dgvProductsInfo.DataSource = clsProductsBusinessLayer.GetAllProductsForInvenotry();

        }

        private void btnOrderVisble()
        {
            if (flowProducts2 != null)

            { flowProducts2.Visible = false; }

            if (OrderContainer != null)
            {
                OrderContainer.Visible = false;

            }
            if (dgvOrdersInfo != null)
            {
                dgvOrdersInfo.Visible = false;

            }
            if (btnBackfromDgvtoOrderContainer != null)
            {
                btnBackfromDgvtoOrderContainer.Visible = false;


            }
            if (btnBackFromOrderContainertoMenu != null)
            {
                btnBackFromOrderContainertoMenu.Visible = false;
            }
        }


        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (flowProducts != null)
            {
                flowProducts.Visible = true;

            }
            btnOrderVisble();
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = false;
                taxSettingsContainer.Visible = false;
            }

            SetupFlowLayoutPanel();

            dgvProductsInfo.Visible = false;
            lblButtonTiltle.Visible = true;
            lnlBtnStatus.Visible = true;
            lblButtonTiltle.Text = "Menu";
            lnlBtnStatus.Text = "Add, edit, or remove menu items";
            float priceinLBP = 85;
            panel1.Clear();

            int[] IDs = clsProductsBusinessLayer.GetProductsByArray();
            int productsNb = IDs.Length;
            for (int i = 0; i < productsNb; i++)
            {
                Panel card = CreateCardPanel(0, 0, 200, 230);
                pd = IDs[i];


                Label lbl = new Label()
                {

                    Text = clsProductsBusinessLayer.GetProducInfotByID(pd).ProductName,
                    Location = new Point(8, 10),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 11, FontStyle.Bold),
                    ForeColor = Color.Black


                };
                card.Controls.Add(lbl);

                Label lblCategory = new Label()
                {
                    Text = clsProductsBusinessLayer.GetProducInfotByID(pd).CategoryName,
                    Location = new Point(8, 35),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),
                    ForeColor = Color.Black



                };
                card.Controls.Add(lblCategory);


                Label lblDescription = new Label()
                {
                    Text = clsProductsBusinessLayer.GetProducInfotByID(pd).desc,
                    Location = new Point(8, 80),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),


                    ForeColor = Color.Gray
                };
                card.Controls.Add(lblDescription);


                float price = clsProductsBusinessLayer.GetProducInfotByID(pd).productPrice;
                priceinLBP = price * 85;
                Label lblPrice = new Label();
                lblPrice.Text = "$" + price.ToString() + "\n";
                lblPrice.Text += "LBP " + priceinLBP.ToString() + "000";

                lblPrice.Font = new Font("Segoe UI", 11, FontStyle.Bold);
                lblPrice.ForeColor = Color.Black;
                lblPrice.Location = new Point(8, 105);
                lblPrice.AutoSize = true;
                card.Controls.Add(lblPrice);

                Label lblstock = new Label()
                {
                    Text = "Stocks: " + clsProductsBusinessLayer.GetProducInfotByID(pd).stock.ToString(),
                    Location = new Point(8, 155),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),


                    ForeColor = Color.Gray


                };
                card.Controls.Add(lblstock);

                Button btnEdit = CreateModernButton("✎", "White", 10, 190, 37, 37);

                btnEdit.Click += (s, e) => EditTheProduct(pd);

                card.Controls.Add(btnEdit);

                // 8️⃣ Delete Button
                Button btndelete = CreateModernButton("🗑️", "White", 60, 190, 37, 37);
                btndelete.Click += (s, e) => DeleteProduct(pd);

                card.Controls.Add(btndelete);





                // 3️⃣ Add the card panel to the form

                panel1.Add(card);
                flowProducts.Controls.Add(card);



            }

            btnAddNewProduct = CreateModernButton("+ Add New Product", "Black", 1050, 150, 184, 45);
            btnAddNewProduct.Click += (s, e) => AddNewProduct();
            btnAddNewProduct.MouseLeave += (s, e) =>
            {
                btnAddNewProduct.BackColor = Color.Black;
                btnAddNewProduct.ForeColor = Color.White;
            };



            this.Controls.Add(btnAddNewProduct);



        }

        private void _RefreshMenu()
        {

            SetupFlowLayoutPanel();

            float priceinLBP = 85;
            panel1.Clear();
            int[] IDs = clsProductsBusinessLayer.GetProductsByArray();
            int productsNb = IDs.Length;
            for (int i = 0; i < productsNb; i++)
            {
                Panel card = CreateCardPanel(0, 0, 200, 230);
                pd = IDs[i];


                Label lbl = new Label()
                {

                    Text = clsProductsBusinessLayer.GetProducInfotByID(pd).ProductName,
                    Location = new Point(8, 10),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 11, FontStyle.Bold),
                    ForeColor = Color.Black


                };
                card.Controls.Add(lbl);

                Label lblCategory = new Label()
                {
                    Text = clsProductsBusinessLayer.GetProducInfotByID(pd).CategoryName,
                    Location = new Point(8, 35),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),
                    ForeColor = Color.Black



                };
                card.Controls.Add(lblCategory);


                Label lblDescription = new Label()
                {
                    Text = clsProductsBusinessLayer.GetProducInfotByID(pd).desc,
                    Location = new Point(8, 80),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),


                    ForeColor = Color.Gray
                };
                card.Controls.Add(lblDescription);


                float price = clsProductsBusinessLayer.GetProducInfotByID(pd).productPrice;
                priceinLBP = price * 85;
                Label lblPrice = new Label();
                lblPrice.Text = "$" + price.ToString() + "\n";
                lblPrice.Text += "LBP " + priceinLBP.ToString() + "000";

                lblPrice.Font = new Font("Segoe UI", 11, FontStyle.Bold);
                lblPrice.ForeColor = Color.Black;
                lblPrice.Location = new Point(8, 105);
                lblPrice.AutoSize = true;
                card.Controls.Add(lblPrice);

                Label lblstock = new Label()
                {
                    Text = "Stocks: " + clsProductsBusinessLayer.GetProducInfotByID(pd).stock.ToString(),
                    Location = new Point(8, 155),
                    AutoSize = true,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold),


                    ForeColor = Color.Gray


                };
                card.Controls.Add(lblstock);

                Button btnEdit = CreateModernButton("✎", "White", 10, 190, 37, 37);

                card.Controls.Add(btnEdit);

                // 8️⃣ Delete Button
                Button btndelete = CreateModernButton("🗑️", "White", 60, 190, 37, 37);
                card.Controls.Add(btndelete);




                // 3️⃣ Add the card panel to the form

                panel1.Add(card);

                flowProducts.Controls.Add(card);






            }


            btnAddNewProduct = CreateModernButton("+ Add New Product", "Black", 1050, 50, 184, 45);
            btnAddNewProduct.MouseLeave += (s, e) =>
            {
                btnAddNewProduct.BackColor = Color.Black;
                btnAddNewProduct.ForeColor = Color.White;
            };

            this.Controls.Add(btnAddNewProduct);


        }

        private void MenuInvisible()
        {

            if (flowProducts != null)
            {
                flowProducts.Controls.Clear();
            }


            panel1.Clear();

        }

        private void CreateDashboardContainers()
        {


        }


        private void btnStaff_Click(object sender, EventArgs e)
        {
            if (taxSettingsContainer != null)
            {
                taxSettingsContainer.Visible = false;

            }
            if (btnAddNewProduct != null)
            {
                btnAddNewProduct.Visible = false;

            }
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = false;

            }
            MenuInvisible();
            if (dgvProductsInfo != null)
                dgvProductsInfo.Visible = false;
            btnOrderVisble();



            lnlBtnStatus.Visible = true;
            lblButtonTiltle.Visible = true;
            lblButtonTiltle.Text = "Staff Managment";
            lnlBtnStatus.Text = "Manage staff accounts and permissions\r\n\r\n";
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            if (btnAddNewProduct != null)
            {
                btnAddNewProduct.Visible = false;

            }
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = true;

            }
            if (flowProducts != null)
            {
                flowProducts.Visible = false;

            }
            btnOrderVisble();
            if (dgvProductsInfo != null)
                dgvProductsInfo.Visible = false;
            MenuInvisible();
            if (btnAddNewProduct != null)
                btnAddNewProduct.Visible = false;
            dgvProductsInfo.Visible = false;
            lnlBtnStatus.Visible = true;
            lblButtonTiltle.Visible = true;
            lblButtonTiltle.Text = "Settings";
            lnlBtnStatus.Text = "Configure your POS system preferences\r\n\r\n";
            CreateStoreInformation();
            CreateTaxSettings();


        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            if (btnAddNewProduct != null)
            {
                btnAddNewProduct.Visible = false;

            }
            if (taxSettingsContainer != null)
            {
                taxSettingsContainer.Visible = false;

            }
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = false;

            }
            MenuInvisible();
            btnOrderVisble();
            if (flowProducts != null)
            {
                flowProducts.Visible = false;

            }

            dgvProductsInfo.Visible = true;
            dgvProductsInfo.CellClick += dgvProductsInfo_CellClick;


            lnlBtnStatus.Visible = true;
            lblButtonTiltle.Visible = true;
            lnlBtnStatus.Text = "Monitor and manage product stock levels\r\n\r\n";
            lblButtonTiltle.Text = "Inventory Managment";
            createProductsTable();



            _RefreshProductsList();







        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            if (btnAddNewProduct != null)
            {
                btnAddNewProduct.Visible = false;

            }
            if (taxSettingsContainer != null)
            {
                taxSettingsContainer.Visible = false;

            }
            if (storeInformationContainer != null)
            {
                storeInformationContainer.Visible = false;

            }
            if (flowProducts != null
                ) flowProducts.Visible = false;
            MenuInvisible();
            btnOrderVisble();
            dgvProductsInfo.Visible = false;
            lnlBtnStatus.Visible = true; lblButtonTiltle.Visible = true;
            lblButtonTiltle.Text = "Sales Reports";
            lnlBtnStatus.Text = "Analyze your business performance";

        }

        private void AddNewProduct()
        {
            AddOrEditProductForm form = new AddOrEditProductForm(0);
            form.ShowDialog();


        }
        private void EditTheProduct(int id)
        {
            if (id != 0)
            {
                AddOrEditProductForm form = new AddOrEditProductForm(id);
                form.ShowDialog();

            }

        }

        private void DeleteProduct(int id)
        {
            DialogResult result = MessageBox.Show(
             "Are you sure you want to delete this product?",
             "Confirm Delete",
              MessageBoxButtons.YesNo,
              MessageBoxIcon.Warning
                 );

            if (result == DialogResult.Yes)
            {
                bool deleted = clsProductsBusinessLayer._DeleteProductbyID(id);

                if (deleted)
                {
                    MessageBox.Show("Product deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    _RefreshMenu(); // refresh the cards
                    _RefreshProductsList();

                }

            }
            else
            {
                MessageBox.Show("Error: Could not delete the product.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void DesignProductsGrid()
        {
            // 🧾 Reset and configure
            dgvProductsInfo.Columns.Clear();
            dgvProductsInfo.AutoGenerateColumns = false;
            dgvProductsInfo.ReadOnly = true;
            dgvProductsInfo.AllowUserToAddRows = false;
            dgvProductsInfo.AllowUserToDeleteRows = false;
            dgvProductsInfo.AllowUserToResizeRows = false;
            dgvProductsInfo.RowHeadersVisible = false;
            dgvProductsInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductsInfo.MultiSelect = false;
            dgvProductsInfo.BorderStyle = BorderStyle.None;
            dgvProductsInfo.BackgroundColor = Color.White;
            dgvProductsInfo.GridColor = Color.FromArgb(240, 240, 240);
            dgvProductsInfo.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvProductsInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // 🧠 Rounded corner illusion
            dgvProductsInfo.EnableHeadersVisualStyles = false;
            dgvProductsInfo.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            // 🎨 Row styling
            dgvProductsInfo.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgvProductsInfo.DefaultCellStyle.ForeColor = Color.Black;
            dgvProductsInfo.DefaultCellStyle.BackColor = Color.White;
            dgvProductsInfo.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(249, 250, 251);
            dgvProductsInfo.DefaultCellStyle.SelectionBackColor = Color.FromArgb(243, 245, 247);
            dgvProductsInfo.DefaultCellStyle.SelectionForeColor = Color.Black;

            dgvProductsInfo.RowTemplate.Height = 36;

            dgvProductsInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                Name = "product_id",
                DataPropertyName = "product_id",
                Visible = false
            });
            // taller for spacing

            dgvProductsInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Product Name",
                DataPropertyName = "product_name",
                FillWeight = 55,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft },



            });



            // 🟤 Category
            dgvProductsInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Category",
                DataPropertyName = "category_name",
                FillWeight = 50,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            });

            // 🟤 Current Stock


            // ✅ Availability checkbox — subtle and flat
            var chkCol = new DataGridViewCheckBoxColumn()
            {
                HeaderText = "Status",
                DataPropertyName = "is_available",
                FillWeight = 30,
                ReadOnly = true,

                FlatStyle = FlatStyle.Flat,

                ThreeState = false
            };
            dgvProductsInfo.Columns.Add(chkCol);


            dgvProductsInfo.Columns.AddRange(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Current Stock",
                DataPropertyName = "Stock",
                FillWeight = 60,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            });


            DataGridViewButtonColumn restockBtn = new DataGridViewButtonColumn();
            restockBtn.HeaderText = "Restock";
            restockBtn.Text = " +  Restock";
            restockBtn.Width = 80;

            restockBtn.UseColumnTextForButtonValue = true;
            restockBtn.Name = "Restock";
            restockBtn.FlatStyle = FlatStyle.Popup;
            dgvProductsInfo.Columns.Add(restockBtn);








            // ⚡ Extra styling for the board effect
            dgvProductsInfo.AdvancedCellBorderStyle.Left = DataGridViewAdvancedCellBorderStyle.None;
            dgvProductsInfo.AdvancedCellBorderStyle.Right = DataGridViewAdvancedCellBorderStyle.None;
            dgvProductsInfo.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.None;
            dgvProductsInfo.AdvancedCellBorderStyle.Bottom = DataGridViewAdvancedCellBorderStyle.Single;

            dgvProductsInfo.CellPainting += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    e.CellStyle.Padding = new Padding(8, 6, 8, 6);
                }
            };
        }


        /*private void DesignOrdersGrid()
        {
            // 🧾 Reset and configure
            dgvOrdersInfo.Columns.Clear();
            dgvOrdersInfo.AutoGenerateColumns = false;
            dgvOrdersInfo.ReadOnly = true;
            dgv.AllowUserToAddRows = false;
            dgvProductsInfo.AllowUserToDeleteRows = false;
            dgvProductsInfo.AllowUserToResizeRows = false;
            dgvProductsInfo.RowHeadersVisible = false;
            dgvProductsInfo.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvProductsInfo.MultiSelect = false;
            dgvProductsInfo.BorderStyle = BorderStyle.None;
            dgvProductsInfo.BackgroundColor = Color.White;
            dgvProductsInfo.GridColor = Color.FromArgb(240, 240, 240);
            dgvProductsInfo.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvProductsInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // 🧠 Rounded corner illusion
            dgvProductsInfo.EnableHeadersVisualStyles = false;
            dgvProductsInfo.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvProductsInfo.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            // 🎨 Row styling
            dgvProductsInfo.DefaultCellStyle.Font = new Font("Segoe UI", 10);
            dgvProductsInfo.DefaultCellStyle.ForeColor = Color.Black;
            dgvProductsInfo.DefaultCellStyle.BackColor = Color.White;
            dgvProductsInfo.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(249, 250, 251);
            dgvProductsInfo.DefaultCellStyle.SelectionBackColor = Color.FromArgb(243, 245, 247);
            dgvProductsInfo.DefaultCellStyle.SelectionForeColor = Color.Black;

            dgvProductsInfo.RowTemplate.Height = 36;

            dgvProductsInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                Name = "product_id",
                DataPropertyName = "product_id",
                Visible = false
            });
            // taller for spacing

            dgvProductsInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Product Name",
                DataPropertyName = "product_name",
                FillWeight = 55,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft },



            });



            // 🟤 Category
            dgvProductsInfo.Columns.Add(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Category",
                DataPropertyName = "category_name",
                FillWeight = 50,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            });

            // 🟤 Current Stock


            // ✅ Availability checkbox — subtle and flat
            var chkCol = new DataGridViewCheckBoxColumn()
            {
                HeaderText = "Status",
                DataPropertyName = "is_available",
                FillWeight = 30,
                ReadOnly = true,

                FlatStyle = FlatStyle.Flat,

                ThreeState = false
            };
            dgvProductsInfo.Columns.Add(chkCol);


            dgvProductsInfo.Columns.AddRange(new DataGridViewTextBoxColumn()
            {
                HeaderText = "Current Stock",
                DataPropertyName = "Stock",
                FillWeight = 60,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleLeft }
            });


            DataGridViewButtonColumn restockBtn = new DataGridViewButtonColumn();
            restockBtn.HeaderText = "Restock";
            restockBtn.Text = " +  Restock";
            restockBtn.Width = 80;

            restockBtn.UseColumnTextForButtonValue = true;
            restockBtn.Name = "Restock";
            restockBtn.FlatStyle = FlatStyle.Popup;
            dgvProductsInfo.Columns.Add(restockBtn);








            // ⚡ Extra styling for the board effect
            dgvProductsInfo.AdvancedCellBorderStyle.Left = DataGridViewAdvancedCellBorderStyle.None;
            dgvProductsInfo.AdvancedCellBorderStyle.Right = DataGridViewAdvancedCellBorderStyle.None;
            dgvProductsInfo.AdvancedCellBorderStyle.Top = DataGridViewAdvancedCellBorderStyle.None;
            dgvProductsInfo.AdvancedCellBorderStyle.Bottom = DataGridViewAdvancedCellBorderStyle.Single;

            dgvProductsInfo.CellPainting += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    e.CellStyle.Padding = new Padding(8, 6, 8, 6);
                }
            };
        }*/


        private int? ShowInputDialog(string message)
        {
            Form prompt = new Form()
            {
                Width = 300,
                Height = 150,

                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = " + Restock",

                StartPosition = FormStartPosition.CenterScreen
            };

            Label lblMessage = new Label() { Left = 20, Top = 20, Text = message, Width = 240 };
            TextBox txtInput = new TextBox() { Left = 20, Top = 50, Width = 240 };
            Button btnOk = new Button() { Text = "OK", Left = 70, Width = 70, Top = 80 };
            Button btnCancel = new Button() { Text = "Cancel", Left = 150, Width = 70, Top = 80 };

            btnOk.DialogResult = DialogResult.OK;
            btnCancel.DialogResult = DialogResult.Cancel;

            prompt.Controls.Add(lblMessage);
            prompt.Controls.Add(txtInput);
            prompt.Controls.Add(btnOk);
            prompt.Controls.Add(btnCancel);

            if (prompt.ShowDialog() == DialogResult.OK)
            {
                if (int.TryParse(txtInput.Text, out int value))
                    return value;
                else
                    MessageBox.Show("Please enter a valid number!");
            }
            return null;
        }


        private void dgvOrdersInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            string columnName = dgvOrdersInfo.Columns[e.ColumnIndex].Name;

            // 🖋️ EDIT
            if (columnName == "Edit")
            {
                DataGridViewRow row = dgvOrdersInfo.Rows[e.RowIndex];

                // Get current quantity
                string currentQty = row.Cells["quantity"].Value?.ToString() ?? "";

                // Ask user for new value
                string input = Interaction.InputBox("Enter new quantity:", "Edit Quantity", currentQty);

                // If user entered something
                if (!string.IsNullOrEmpty(input))
                {
                    if (int.TryParse(input, out int newQty) && newQty > 0)
                    {
                        // ✅ Update the cell value
                        row.Cells["quantity"].Value = newQty;

                        // Optional: highlight the row briefly
                        row.DefaultCellStyle.BackColor = Color.LightGreen;

                        MessageBox.Show("✅ Quantity updated successfully!");
                    }
                    else
                    {
                        MessageBox.Show("⚠️ Please enter a valid positive number.");
                    }
                }
                else
                {
                    MessageBox.Show("⚠️ No changes made.");
                }
            }

            // 🗑️ DELETE
            else if (columnName == "Delete")
            {
                if (MessageBox.Show("Are you sure you want to delete this item?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    dgvOrdersInfo.Rows.RemoveAt(e.RowIndex);
                }
            }
        }



        private void dgvProductsInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvProductsInfo.Columns[e.ColumnIndex].Name == "Restock")
            {
                int productID = Convert.ToInt32(dgvProductsInfo.Rows[e.RowIndex].Cells["product_id"].Value);

                int? addedStock = ShowInputDialog("Enter stock quantity to ADD:");

                if (addedStock != null && addedStock > 0)
                {
                    bool success = clsProductsBusinessLayer._Add_To_Inventory(productID, addedStock.Value);

                    if (success)
                    {
                        MessageBox.Show("Stock updated successfully!");
                        _RefreshProductsList();
                    }
                    else
                    {
                        MessageBox.Show("Error updating stock.");
                    }


                }
            }
        }




        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void addProductToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private Panel CreateCardPanel(int x, int y, int width = 200, int height = 250)
        {
            // 1. Create the panel
            Panel card = new Panel();
            card.Location = new Point(x, y);   // Position
            card.Size = new Size(width, height);
            card.BackColor = Color.White;      // Card background
            card.BorderStyle = BorderStyle.None;

            // 2. Optional: Add shadow effect (simple)
            card.Paint += (s, e) =>
            {
                using (Graphics g = e.Graphics)
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    Rectangle rect = new Rectangle(0, 0, card.Width - 1, card.Height - 1);

                    using (GraphicsPath path = new GraphicsPath())
                    {
                        int radius = 15; // Rounded corner radius
                        path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                        path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                        path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                        path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                        path.CloseFigure();

                        using (SolidBrush brush = new SolidBrush(Color.White))
                            g.FillPath(brush, path);

                        using (Pen pen = new Pen(Color.LightGray, 2))
                            g.DrawPath(pen, path);
                    }
                }
            };

            return card;
        }


        private Button CreateModernButton(string text, string bcolor, int x, int y, int width = 100, int height = 40)
        {

            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(width, height);
            btn.FlatStyle = FlatStyle.Flat;
            if (bcolor == "Black")
            {
                btn.ForeColor = Color.White;
                btn.BackColor = Color.Black;


            }
            else
            {
                btn.ForeColor = Color.Black;
                btn.BackColor = Color.White;

            }


            btn.Font = new Font("Segoe UI", 10, FontStyle.Regular);

            // Make the border light gray and no thick frame
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = Color.LightGray;

            // Optional: rounded corners
            btn.Region = System.Drawing.Region.FromHrgn(
                CreateRoundRectRgn(0, 0, btn.Width, btn.Height, 10, 10)
            );

            // Hover effect
            btn.MouseEnter += (s, e) =>
            {
                btn.BackColor = Color.LightGray;
                btn.ForeColor = Color.Black;

            };
            if (bcolor == "Black")
            {
                btn.MouseLeave += (s, e) =>
                {
                    btn.BackColor = Color.Black;
                    btn.ForeColor = Color.White;
                };
            }
            else
            {
                btn.MouseLeave += (s, e) =>
                {
                    btn.BackColor = Color.White;

                };

            }

            return btn;
        }

        // Import this for rounded corners
        [System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse
        );
        private void SetupFlowLayoutPanel()
        {
            if (flowProducts == null)
            {
                flowProducts = new FlowLayoutPanel();
                flowProducts.Location = new Point(260, 200);
                flowProducts.Size = new Size(1050, 500);
                flowProducts.AutoScroll = true;             // <-- allows scrolling
                flowProducts.WrapContents = true;           // wrap to next line automatically
                flowProducts.FlowDirection = FlowDirection.LeftToRight;
                flowProducts.BackColor = Color.WhiteSmoke;  // optional aesthetic
                this.Controls.Add(flowProducts);
            }

            flowProducts.Controls.Clear(); // clear previous cards
        }

        private void SetupFlowLayoutPanel2()
        {
            if (flowProducts2 == null)
            {
                flowProducts2 = new FlowLayoutPanel();
                flowProducts2.Location = new Point(260, 200);
                flowProducts2.Size = new Size(1050, 500);
                flowProducts2.AutoScroll = true;             // <-- allows scrolling
                flowProducts2.WrapContents = true;           // wrap to next line automatically
                flowProducts2.FlowDirection = FlowDirection.LeftToRight;
                flowProducts2.BackColor = Color.WhiteSmoke;
                // optional aesthetic

                this.Controls.Add(flowProducts2);
            }

            flowProducts2.Controls.Clear(); // clear previous cards
        }


        private int GetNumberOfProducts()
        {
            return clsProductsBusinessLayer._getProductsNumber();
        }

        private Panel CreateBigContainer(int x, int y, int width, int height)
        {
            Panel container = new Panel();
            container.Location = new Point(x, y);
            container.Size = new Size(width, height);
            container.BackColor = Color.White;
            container.BorderStyle = BorderStyle.None;

            container.Paint += (s, e) =>
            {
                using (Graphics g = e.Graphics)
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    Rectangle rect = new Rectangle(0, 0, container.Width - 1, container.Height - 1);

                    using (GraphicsPath path = new GraphicsPath())
                    {
                        int radius = 20;
                        path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                        path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                        path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                        path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                        path.CloseFigure();

                        using (SolidBrush brush = new SolidBrush(Color.White))
                            g.FillPath(brush, path);

                        using (Pen pen = new Pen(Color.LightGray, 2))
                            g.DrawPath(pen, path);
                    }
                }
            };

            return container;
        }


        private TextBox CreateSettingTextbox(string placeholder, int top)
        {
            TextBox txt = new TextBox();
            txt.Size = new Size(350, 30);
            txt.Multiline = true;
            txt.Location = new Point(15, top);

            txt.Font = new Font("Segoe UI", 10);
            txt.BorderStyle = BorderStyle.None;
            txt.BackColor = Color.FromArgb(244, 244, 244); // light gray background
            txt.ForeColor = Color.Black;


            txt.PlaceholderText = placeholder;

            txt.Padding = new Padding(5);
            txt.Region = System.Drawing.Region.FromHrgn(
              CreateRoundRectRgn(0, 0, txt.Width, txt.Height, 5, 5));

            // Wrap it in a rounded panel

            return txt;
        }

        private Label CreateFieldLabel(string title, int top)
        {
            return new Label()
            {
                Text = title,
                Location = new Point(20, top),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                AutoSize = true
            };
        }



        private Panel CreateLargeContainer(int x, int y, int width = 1100, int height = 400)
        {
            Panel container = new Panel();
            container.Location = new Point(x, y);
            container.Size = new Size(width, height);
            container.BackColor = Color.White;
            container.BorderStyle = BorderStyle.None;

            // Rounded border
            container.Paint += (s, e) =>
            {
                using (Graphics g = e.Graphics)
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    Rectangle rect = new Rectangle(0, 0, container.Width - 1, container.Height - 1);

                    using (GraphicsPath path = new GraphicsPath())
                    {
                        int radius = 20;
                        path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                        path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                        path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                        path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                        path.CloseFigure();

                        using (SolidBrush brush = new SolidBrush(Color.White))
                            g.FillPath(brush, path);

                        using (Pen pen = new Pen(Color.LightGray, 2))
                            g.DrawPath(pen, path);
                    }
                }
            };

            return container;
        }

        private void CreateLargeSettingFields()
        {
            // Create big container
            Panel bigContainer = CreateLargeContainer(260, 200, 1050, 450);
            this.Controls.Add(bigContainer);

            int y = 20;

            // Add title
            Label lblTitle = new Label()
            {
                Text = "Store Information",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Location = new Point(20, y),
                AutoSize = true
            };
            bigContainer.Controls.Add(lblTitle);
            y += 40;

            // Store Name
            bigContainer.Controls.Add(CreateFieldLabel("Store Name *", y));
            y += 25;
            bigContainer.Controls.Add(CreateSettingTextbox("Nova Coffee Shop", y));
            y += 60;

            // Store Address
            bigContainer.Controls.Add(CreateFieldLabel("Store Address", y));
            y += 25;
            bigContainer.Controls.Add(CreateSettingTextbox("123 Main Street, Beirut, Lebanon", y));
            y += 60;

            // Store Phone
            bigContainer.Controls.Add(CreateFieldLabel("Store Phone", y));
            y += 25;
            bigContainer.Controls.Add(CreateSettingTextbox("+961 1 234 567", y));
            y += 60;

            // Receipt Footer Message
            bigContainer.Controls.Add(CreateFieldLabel("Receipt Footer Message", y));
            y += 25;
            bigContainer.Controls.Add(CreateSettingTextbox("Thank you for your business!", y));
        }


        private void CreateStoreInformation()
        {
            storeInformationContainer = CreateCardPanel(280, 170, 400, 500);
            Label lblstore = new Label();
            lblstore.Text = "Store Name *";
            lblstore.Location = new Point(15, 15);
            lblstore.ForeColor = Color.Black;
            storeInformationContainer.Controls.Add(lblstore);
            TextBox txtStoreName = CreateSettingTextbox("Nova Coffee Shop", 55);
            txtStoreName.ReadOnly = true;


            storeInformationContainer.Controls.Add(txtStoreName);
            Label lblAddress = new Label();
            lblAddress.Text = "Store Address";
            lblAddress.Location = new Point(15, 105);
            lblAddress.ForeColor = Color.Black;
            storeInformationContainer.Controls.Add(lblAddress);
            TextBox txtAddress = CreateSettingTextbox("Beirut Hamra street", 135);
            storeInformationContainer.Controls.Add(txtAddress);

            Label lblStorePhone = new Label();
            lblStorePhone.Text = "Store Phone";
            lblStorePhone.Location = new Point(15, 185);
            lblStorePhone.ForeColor = Color.Black;
            storeInformationContainer.Controls.Add(lblStorePhone);
            TextBox txtPhone = CreateSettingTextbox("76 555 777", 215);
            txtPhone.ReadOnly = true;
            storeInformationContainer.Controls.Add(txtPhone);


            Label lblEmail = new Label();
            lblEmail.Text = "Store Email";
            lblEmail.Location = new Point(15, 265);
            lblEmail.ForeColor = Color.Black;
            storeInformationContainer.Controls.Add(lblEmail);
            TextBox txtEmail = CreateSettingTextbox("nova@gmail.com", 295);
            txtEmail.ReadOnly = true;
            storeInformationContainer.Controls.Add(txtEmail);


            Label lblCampus = new Label();
            lblCampus.Text = "Campus Name";
            lblCampus.Location = new Point(15, 345);
            lblCampus.ForeColor = Color.Black;
            storeInformationContainer.Controls.Add(lblCampus);
            TextBox txtCampus = CreateSettingTextbox("Hamra ", 375);
            txtCampus.ReadOnly = true;
            storeInformationContainer.Controls.Add(txtCampus);








            this.Controls.Add(storeInformationContainer);

        }

        private void CreateTaxSettings()
        {
            taxSettingsContainer = CreateCardPanel(750, 170, 400, 500);
            Label lblCurrency = new Label();
            lblCurrency.Text = "Default Currency ";
            lblCurrency.Location = new Point(15, 15);
            lblCurrency.ForeColor = Color.Black;
            taxSettingsContainer.Controls.Add(lblCurrency);
            TextBox txtCurrency = CreateSettingTextbox("USD Dollar $", 45);
            txtCurrency.ReadOnly = true;
            taxSettingsContainer.Controls.Add(txtCurrency);

            Label lblTaxRate = new Label();
            lblTaxRate.Text = "Tax Rate %:";
            lblTaxRate.Location = new Point(15, 105);
            lblTaxRate.ForeColor = Color.Black;
            taxSettingsContainer.Controls.Add(lblTaxRate);
            TextBox txtTax = CreateSettingTextbox("11", 130);
            taxSettingsContainer.Controls.Add(txtTax);


            this.Controls.Add(taxSettingsContainer);


        }

        private void AdminControlPresentation_Paint(object sender, PaintEventArgs e)
        {
            Color black = Color.Gray;
            Pen pen = new Pen(black);
            pen.Width = 2;
            Pen pen2 = new Pen(black);

            pen.StartCap=System.Drawing.Drawing2D.LineCap.Round;
            pen.EndCap= System.Drawing.Drawing2D.LineCap.Round;
            e.Graphics.DrawLine(pen, 240, 90, 240, 900);
            e.Graphics.DrawLine(pen2, -20, 90, 1400, 90);
        }
    }

}

