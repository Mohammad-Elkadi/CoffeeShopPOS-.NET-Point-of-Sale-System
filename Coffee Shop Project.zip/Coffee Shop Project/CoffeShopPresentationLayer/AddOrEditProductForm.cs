﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;
using ProductsBusinessLayer;
using System.Windows.Forms;

namespace CoffeShopPresentationLayer
{
    public partial class AddOrEditProductForm : Form
    {
        private TextBox txtName, txtPriceUSD, txtPriceLBP, txtStock, txtDescription;
        private ComboBox cmbCategory;
        private CheckBox chkActive;
        private Button btnSave, btnCancel;
        private int id;

        public AddOrEditProductForm(int i)
        {
            id = i;
            
            InitializeComponent();
            if (i==0)
            {
                this.Text = "Add New Product";
                
            }
            else { this.Text = "Edit a Product"; }
            this.Size = new Size(650, 500);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = Color.White;

            InitializeUI(i);
        }

        private void AddOrEditProductForm_Load(object sender, EventArgs e)
        {

        }

        private void InitializeUI(int i)
        {
            // ===== Title =====
            Label lblTitle = new Label()
            {
                Text = i == 0 ? "Add Product" : "Edit Product",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.Black,
                Location = new Point(25, 20),
                AutoSize = true
            };
            Controls.Add(lblTitle);

            // ===== Product Name =====
            Controls.Add(new Label()
            {

                Text = "Product Name *",
                Font = new Font("Segoe UI", 10),
                Location = new Point(25, 70)
            });
            txtName = CreateModernTextBox(i == 0 ? "Enter product name" : clsProductsBusinessLayer.GetProducInfotByID(id).ProductName, 25, 95, 320);

            // ===== Category =====
            Controls.Add(new Label()
            {
                Text = "Category *",
                Font = new Font("Segoe UI", 10),
                Location = new Point(400, 70)
            });
            cmbCategory = new ComboBox()
            {
                Location = new Point(400, 95),
                Size = new Size(220, 35),
                Font = new Font("Segoe UI", 10),
                DropDownStyle = ComboBoxStyle.DropDownList,
                FlatStyle = FlatStyle.Flat
            };

            var categories = clsProductsBusinessLayer._GetAllCatergoriesName();
            if (categories != null && categories.Rows.Count > 0)
            {
                cmbCategory.DataSource = categories;
                cmbCategory.DisplayMember = "name";
                cmbCategory.ValueMember = "category_id";
            }



            if (cmbCategory.Items.Count > 0) cmbCategory.SelectedIndex = 0;
            Controls.Add(cmbCategory);

            // ===== Prices =====
            Controls.Add(new Label()
            {
                Text = "Price (LBP) *",
                Font = new Font("Segoe UI", 10),
                Location = new Point(25, 150)
            });
            txtPriceLBP = CreateModernTextBox(i==0 ? "0": clsProductsBusinessLayer.GetProducInfotByID(id).productPrice.ToString(), 25, 175, 150);


            Controls.Add(new Label()
            {
                Text = "Price (USD) *",
                Font = new Font("Segoe UI", 10),
                Location = new Point(200, 150)
            });
            txtPriceUSD = CreateModernTextBox(i==0 ? "0":clsProductsBusinessLayer.GetProducInfotByID(id).productPrice.ToString(), 200, 175, 150);

            // ===== Stock =====
            Controls.Add(new Label()
            {
                Text = "Stock",
                Font = new Font("Segoe UI", 10),
                Location = new Point(400, 150)
            });
            txtStock = CreateModernTextBox(i == 0 ? "0" : clsProductsBusinessLayer.GetProducInfotByID(i).stock.ToString(), 400, 175, 150);

            // ===== Description =====
            Controls.Add(new Label()
            {
                Text = "Description",
                Font = new Font("Segoe UI", 10),
                Location = new Point(25, 230)
            });
            txtDescription = CreateModernTextBox(i ==0 ? "Product Description":clsProductsBusinessLayer.GetProducInfotByID(i).desc, 25, 255, 600, 100);
            txtDescription.Multiline = true;
            txtDescription.AcceptsReturn = true;

            // ===== Active Checkbox =====
            chkActive = new CheckBox()
            {
                Text = "Active",
                Location = new Point(25, 370),
                Font = new Font("Segoe UI", 10),
                AutoSize = true
            };
            Controls.Add(chkActive);

            // ===== Buttons =====
            btnCancel = CreateModernButton("Cancel", "Black", 380, 410, 110, 40);
            btnCancel.FlatStyle=FlatStyle.Flat;
           
            btnCancel.Click += (s, e) => this.Close();
            Controls.Add(btnCancel);


            btnSave = CreateModernButton("Save", "Black", 510, 410, 110, 40);
           
            btnSave.Click += BtnSave_Click;
            Controls.Add(btnSave);
        }

        private TextBox CreateModernTextBox(string placeholder, int x, int y, int width = 250, int height = 35)
        {
            // Outer container (for border)
            Panel container = new Panel
            {
                Location = new Point(x, y),
                Size = new Size(width, height),
                BackColor = Color.Transparent
            };

            // Draw rounded border and background
            container.Paint += (s, e) =>
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (Pen pen = new Pen(Color.FromArgb(220, 220, 225), 1))
                using (Brush brush = new SolidBrush(Color.FromArgb(245, 245, 247)))
                using (System.Drawing.Drawing2D.GraphicsPath path = RoundedRect(
                    new Rectangle(0, 0, container.Width - 1, container.Height - 1), 8))
                {
                    e.Graphics.FillPath(brush, path);
                    e.Graphics.DrawPath(pen, path);
                }
            };

            // Actual textbox
            TextBox txt = new TextBox
            {
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.Gray,
                BackColor = Color.FromArgb(245, 245, 247),
                BorderStyle = BorderStyle.None,
                Location = new Point(12, 8),
                Size = new Size(width - 24, height - 16),
                Multiline = false,
                Text = placeholder
            };

            // Placeholder logic
            txt.GotFocus += (s, e) =>
            {
                if (txt.Text == placeholder)
                {
                    txt.Text = "";
                    txt.ForeColor = Color.Black;
                }
            };
            txt.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txt.Text))
                {
                    txt.Text = placeholder;
                    txt.ForeColor = Color.Gray;
                }
            };

            container.Controls.Add(txt);
            Controls.Add(container);
            txt.BringToFront();

            return txt;
        }



        // Adds placeholder (gray text) that clears on focus and restores on empty lose-focus
        private void SetPlaceholderBehavior(TextBox txt, string placeholder)
        {
            txt.Tag = placeholder;
            txt.Text = placeholder;
            txt.ForeColor = Color.Gray;
            txt.ReadOnly = false;

            txt.GotFocus += (s, e) =>
            {
                if (txt.Text == (string)txt.Tag)
                {
                    txt.Text = "";
                    txt.ForeColor = Color.Black;
                }
            };

            txt.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txt.Text))
                {
                    txt.Text = (string)txt.Tag;
                    txt.ForeColor = Color.Gray;
                }
            };
        }


        private System.Drawing.Drawing2D.GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            int d = radius * 2;
            path.AddArc(bounds.Left, bounds.Top, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Top, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Optional P/Invoke if you prefer native rounding (not required here)
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse
        );

        // Save button handler (call business layer to add product)
        private void BtnSave_Click(object sender, EventArgs e)
        {

            // Example: read values (ignore placeholder values)
            string name = (txtName.Text == (string)txtName.Tag) ? "" : txtName.Text.Trim();
            string desc = (txtDescription.Text == (string)txtDescription.Tag) ? "" : txtDescription.Text.Trim();

            if (!float.TryParse((txtPriceUSD.Text == (string)txtPriceUSD.Tag) ? "0" : txtPriceUSD.Text, out float priceUSD))
                priceUSD = 0;

            if (!int.TryParse((txtStock.Text == (string)txtStock.Tag) ? "0" : txtStock.Text, out int stock))
                stock = 0;

            bool isActive = chkActive.Checked;


            if (cmbCategory.SelectedValue == null)
            {
                MessageBox.Show("Please select a category.","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            int categoryID = Convert.ToInt32(cmbCategory.SelectedValue);





            if (id > 0)
            {


                bool isEdit = clsProductsBusinessLayer._UpdateProduct(id,name, categoryID,priceUSD,desc,stock,"gg ");
                if (isEdit) { MessageBox.Show("The product is  edit succesfully!", "Succes", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                this.DialogResult= DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to Edit product.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


                }
               
            }
            if (id == 0)
            {
                var categories = clsProductsBusinessLayer._GetAllCatergoriesName();
                if (categories != null && categories.Rows.Count > 0)
                {
                    cmbCategory.DataSource = categories;
                    cmbCategory.DisplayMember = "name";        // what user sees
                    cmbCategory.ValueMember = "category_id";   // actual ID value
                }

                bool added = clsProductsBusinessLayer._AddNewProduct(name,categoryID,priceUSD,desc,stock,"hh");


                if (added)
                {
                    MessageBox.Show("Product added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to add product.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            
        }


        private Button CreateModernButton(string text, string bcolor, int x, int y, int width = 100, int height = 40)
        {

            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(width, height);
            btn.FlatStyle = FlatStyle.Flat;
            if (bcolor == "Black")
            {
                btn.ForeColor = Color.White;
                btn.BackColor = Color.Black;


            }
            else
            {
                btn.ForeColor = Color.Black;
                btn.BackColor = Color.White;

            }


            btn.Font = new Font("Segoe UI", 10, FontStyle.Regular);

            // Make the border light gray and no thick frame
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = Color.LightGray;

            // Optional: rounded corners
            btn.Region = System.Drawing.Region.FromHrgn(
                CreateRoundRectRgn(0, 0, btn.Width, btn.Height, 10, 10)
            );

            // Hover effect
            btn.MouseEnter += (s, e) =>
            {
                btn.BackColor = Color.LightGray;
                btn.ForeColor = Color.Black;

            };
            btn.MouseLeave += (s, e) =>
            {
                btn.BackColor = Color.Black;
                btn.ForeColor = Color.White;    
            };

            return btn;
        }

        // Import this for rounded corners
      


    }
}
    

