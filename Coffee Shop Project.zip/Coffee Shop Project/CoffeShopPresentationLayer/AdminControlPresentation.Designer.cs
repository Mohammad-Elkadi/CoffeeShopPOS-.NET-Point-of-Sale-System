﻿namespace CoffeShopPresentationLayer
{
    partial class AdminControlPresentation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminControlPresentation));
            pictureBox1 = new PictureBox();
            lblName = new Label();
            lblstatus = new Label();
            btnDashboard = new Button();
            btnNewOrder = new Button();
            lblButtonTiltle = new Label();
            lnlBtnStatus = new Label();
            btnMenu = new Button();
            btnStaff = new Button();
            btnSettings = new Button();
            btnInventory = new Button();
            btnReports = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.None;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(2, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(118, 76);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Font = new Font("Segoe UI Variable Text", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblName.Location = new Point(126, 3);
            lblName.Name = "lblName";
            lblName.Size = new Size(121, 26);
            lblName.TabIndex = 1;
            lblName.Text = "Coffee Shop";
            // 
            // lblstatus
            // 
            lblstatus.AutoSize = true;
            lblstatus.Location = new Point(126, 51);
            lblstatus.Name = "lblstatus";
            lblstatus.Size = new Size(72, 15);
            lblstatus.TabIndex = 2;
            lblstatus.Text = "Point of sale";
            lblstatus.Visible = false;
            // 
            // btnDashboard
            // 
            btnDashboard.Cursor = Cursors.Hand;
            btnDashboard.Font = new Font("Segoe UI Emoji", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashboard.ImageAlign = ContentAlignment.MiddleLeft;
            btnDashboard.Location = new Point(0, 109);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(182, 50);
            btnDashboard.TabIndex = 3;
            btnDashboard.Text = "📊 Dashboard";
            btnDashboard.TextAlign = ContentAlignment.MiddleLeft;
            btnDashboard.UseVisualStyleBackColor = true;
            btnDashboard.Click += button1_Click;
            // 
            // btnNewOrder
            // 
            btnNewOrder.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNewOrder.Location = new Point(-2, 165);
            btnNewOrder.Name = "btnNewOrder";
            btnNewOrder.Size = new Size(184, 52);
            btnNewOrder.TabIndex = 4;
            btnNewOrder.Text = "\U0001f6d2 New Order";
            btnNewOrder.TextAlign = ContentAlignment.MiddleLeft;
            btnNewOrder.UseVisualStyleBackColor = true;
            btnNewOrder.Click += btnNewOrder_Click;
            // 
            // lblButtonTiltle
            // 
            lblButtonTiltle.AutoSize = true;
            lblButtonTiltle.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblButtonTiltle.Location = new Point(279, 96);
            lblButtonTiltle.Name = "lblButtonTiltle";
            lblButtonTiltle.Size = new Size(0, 20);
            lblButtonTiltle.TabIndex = 5;
            lblButtonTiltle.Tag = "label1";
            lblButtonTiltle.Visible = false;
            // 
            // lnlBtnStatus
            // 
            lnlBtnStatus.AutoSize = true;
            lnlBtnStatus.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lnlBtnStatus.Location = new Point(279, 126);
            lnlBtnStatus.Name = "lnlBtnStatus";
            lnlBtnStatus.Size = new Size(0, 20);
            lnlBtnStatus.TabIndex = 6;
            lnlBtnStatus.Visible = false;
            // 
            // btnMenu
            // 
            btnMenu.FlatStyle = FlatStyle.Flat;
            btnMenu.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMenu.Location = new Point(0, 223);
            btnMenu.Name = "btnMenu";
            btnMenu.Size = new Size(184, 52);
            btnMenu.TabIndex = 7;
            btnMenu.Text = "☰  Menu";
            btnMenu.TextAlign = ContentAlignment.MiddleLeft;
            btnMenu.UseVisualStyleBackColor = true;
            btnMenu.Click += btnMenu_Click;
            // 
            // btnStaff
            // 
            btnStaff.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStaff.Location = new Point(0, 339);
            btnStaff.Name = "btnStaff";
            btnStaff.Size = new Size(184, 52);
            btnStaff.TabIndex = 8;
            btnStaff.Text = "👥 Staff";
            btnStaff.TextAlign = ContentAlignment.MiddleLeft;
            btnStaff.UseVisualStyleBackColor = true;
            btnStaff.Click += btnStaff_Click;
            // 
            // btnSettings
            // 
            btnSettings.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSettings.Location = new Point(0, 455);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(184, 52);
            btnSettings.TabIndex = 9;
            btnSettings.Text = "⚙️ Settings";
            btnSettings.TextAlign = ContentAlignment.MiddleLeft;
            btnSettings.UseVisualStyleBackColor = true;
            btnSettings.Click += btnSettings_Click;
            // 
            // btnInventory
            // 
            btnInventory.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInventory.Location = new Point(0, 281);
            btnInventory.Name = "btnInventory";
            btnInventory.Size = new Size(184, 52);
            btnInventory.TabIndex = 10;
            btnInventory.Text = "📦 Inventory";
            btnInventory.TextAlign = ContentAlignment.MiddleLeft;
            btnInventory.UseVisualStyleBackColor = true;
            btnInventory.Click += btnInventory_Click;
            // 
            // btnReports
            // 
            btnReports.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReports.Location = new Point(-2, 395);
            btnReports.Name = "btnReports";
            btnReports.Size = new Size(184, 52);
            btnReports.TabIndex = 11;
            btnReports.Text = "📊 Reports";
            btnReports.TextAlign = ContentAlignment.MiddleLeft;
            btnReports.UseVisualStyleBackColor = true;
            btnReports.Click += btnReports_Click;
            // 
            // AdminControlPresentation
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1112, 572);
            Controls.Add(btnReports);
            Controls.Add(btnInventory);
            Controls.Add(btnSettings);
            Controls.Add(btnStaff);
            Controls.Add(btnMenu);
            Controls.Add(lnlBtnStatus);
            Controls.Add(lblButtonTiltle);
            Controls.Add(btnNewOrder);
            Controls.Add(btnDashboard);
            Controls.Add(lblstatus);
            Controls.Add(lblName);
            Controls.Add(pictureBox1);
            Name = "AdminControlPresentation";
            Padding = new Padding(10, 0, 0, 0);
            Text = "Nova Coffee Shop";
            Load += AdminControlPresentation_Load;
            Paint += AdminControlPresentation_Paint;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblName;
        private Label lblstatus;
        public PictureBox pictureBox1;
        private Button btnDashboard;
        private Button btnNewOrder;
        private Label lblButtonTiltle;
        private Label lnlBtnStatus;
        private Button btnMenu;
        private Button btnStaff;
        private Button btnSettings;
        private Button btnInventory;
        private Button btnReports;
        private DataGridViewTextBoxColumn Product_id;
        private DataGridViewTextBoxColumn Product_Name;
        private DataGridViewTextBoxColumn CattegoryInfo;
        private DataGridViewTextBoxColumn Is_Available;
        private DataGridViewTextBoxColumn price;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}