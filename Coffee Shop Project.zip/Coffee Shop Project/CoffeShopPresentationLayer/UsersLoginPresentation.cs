using UserBusinessLayer;

namespace CoffeShopPresentationLayer
{
    public partial class UsersLoginPresentation : Form
    {
        public UsersLoginPresentation()
        {
           
            InitializeComponent();
            ShowButton();
          


        }

      



        private void UsersLoginPresentation_Load(object sender, EventArgs e)
        {

        }
        private void textBoxsStyle()
        {
            txtUserID.BackColor = Color.FromArgb(10, 10, 25);
            txtPassword.BackColor = Color.FromArgb(10, 10, 25);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtUserID.Text);
            clsUserBusinessLayer user = clsUserBusinessLayer.FindUserInfo(id, txtPassword.Text);
            if (user != null) {
                MessageBox.Show("Welcome " + user.lastname);
                AdminControlPresentation form = new AdminControlPresentation();
                this.Close();
                form.Show();

            }
            else
            {
                MessageBox.Show("It is wrong");
               
            }

        }
        private void ShowButton()
        {
            Button button = CreateModernButton("Login", 538, 348, 245, 48);
            
            button.BackColor = Color.Black;
            button.ForeColor = Color.White;

            // ?? Attach the event directly here (your own custom logic)
            button.Click += (s, e) =>
            {

                try
                {
                    // Get and validate user ID
                    if (!int.TryParse(txtUserID.Text, out int UID))
                    {
                        MessageBox.Show("Please enter a valid numeric User ID!");
                        return;
                    }

                    // Get user info
                    clsUserBusinessLayer user = clsUserBusinessLayer.FindUserInfo(UID, txtPassword.Text);

                    if (user != null)
                    {
                        MessageBox.Show("Welcome " + user.lastname);
                        AdminControlPresentation form = new AdminControlPresentation();
                        UsersLoginPresentation usersLoginPresentation = new UsersLoginPresentation();
                        
                        form.Show();
                        this.Hide();
                       
                    }
                    else
                    {
                        MessageBox.Show("User ID or Password is incorrect.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
            };
           

            button.MouseLeave += (s, e) =>
            {
                button.BackColor= Color.Black;
                button.ForeColor= Color.White;

            };

            // Finally, add it to your form
            this.Controls.Add(button);
            

        }


        private Button CreateModernButton(string text, int x, int y, int width = 100, int height = 40)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(width, height);
            btn.FlatStyle = FlatStyle.Flat;
            btn.BackColor = Color.White;
            btn.ForeColor = Color.Black;
            btn.Font = new Font("Segoe UI", 10, FontStyle.Regular);

            // Make the border light gray and no thick frame
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = Color.LightGray;

            // Optional: rounded corners
            btn.Region = System.Drawing.Region.FromHrgn(
                CreateRoundRectRgn(0, 0, btn.Width, btn.Height, 10, 10)
            );

            // Hover effect
            btn.MouseEnter += (s, e) =>
            {
                btn.BackColor = Color.LightGray;
                btn.ForeColor = Color.Black;

            };
            btn.MouseLeave += (s, e) =>
            {
                btn.BackColor = Color.White;
            };

            return btn;
        }

        // Import this for rounded corners
        [System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse
        );
    }
}
