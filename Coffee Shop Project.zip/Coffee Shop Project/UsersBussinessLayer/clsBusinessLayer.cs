﻿using System;
using System.Collections.Generic;
using System.Linq;
using UsersDataAcessLayers;
using System.Text;
using System.Threading.Tasks;

namespace UsersBussinessLayer
{
    public class clsBusinessLayer
    {
        public enum enUser { Admin = 0, Employe = 1 };
        public enUser Mode = enUser.Employe;
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string password { get; set; }
        public string LastName { get; set; }
        public string address { get; set; }
        public string Phone { get; set; }
        public string role { get; set; }
        public DateTime date_of_birth { get; set; }
        public int campusID { get; set; }

        public clsBusinessLayer(int ID, string password, string FirstName, string lastName, string phone, string address, string role,
            DateTime d, int campusID)
        {
            this.LastName = lastName;
            this.FirstName = FirstName;
            this.ID = ID;
            this.role = role;
            this.address = address;
            this.date_of_birth = d;
            this.Phone = phone;
            this.campusID = campusID;
            this.password = password;

        }
        public static clsBusinessLayer FindUser(string ID, string Password)
        {
            int id = int.Parse(ID);

            string lastName = "", FirstName = "", phone = "", role = "", address = "";
            int CampusID = 0;
            DateTime date = DateTime.Now;

            if (clsUsersDataAccessLayer.getUser(id, Password, ref FirstName, ref lastName, ref phone, ref address, ref role, ref date, ref CampusID))
            {
                return new clsBusinessLayer(id, Password, FirstName, lastName, phone, address, role, date, CampusID);

            }
            return null;

        }



    }
}
