﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace OrderDataAccessLayer
{
    public class clsOrderDataAccessLayer
    {
        public static string connectionString = "Server=LAPTOP-U3G4VRD6\\MYSQLSERVER1;Database=CoffeeShopDB;Integrated Security=True;";
        public static int AddNewOrder(DateTime date_of_order,string notes,string type_of_payment,
          float total_price ,int campusID )
        {
            int rowsAffected = 0;
            SqlConnection connection= new SqlConnection(connectionString);
            string query ="INSERT into Orders (date_of_order,notes,type_of_payment,total_price," +
                "campusID) Values(@date_of_order,@notes,@type_of_payment,@total_price,@campusID);SELECT SCOPE_IDENTITY();";
             SqlCommand command =  new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@date_of_order", date_of_order);
            command.Parameters.AddWithValue("@notes",notes);
            command.Parameters.AddWithValue ("@type_of_payment", type_of_payment);
            command.Parameters.AddWithValue("@total_price", total_price);
            command.Parameters.AddWithValue("@campusID", campusID);


            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    rowsAffected = insertedID;
                }

            }
            catch (Exception ex) { connection.Close(); }finally { connection.Close(); }


            return rowsAffected;


        }

        public static int _AddNewOrderItems(int order_id,int product_id,float unit_price,int quantity)
        {
            int rowsAffected = 0;

            
            SqlConnection connection= new SqlConnection(connectionString);
            string query = @"INSERT into OrderItems (order_id,product_id,unit_price,quantity) values " +
                " (@order_id,@product_id,@unit_price,@quantity);SELECT SCOPE_IDENTITY();";
            SqlCommand command= new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@order_id", order_id);
            command.Parameters.AddWithValue("@product_id", product_id);
            command.Parameters.AddWithValue("@unit_price",unit_price);
            command.Parameters.AddWithValue("@quantity", quantity);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && int.TryParse(result.ToString(), out int id))
                {
                    rowsAffected= id;
                }



            }
            catch (Exception ex) { connection.Close(); } finally { connection.Close(); }
            return rowsAffected;



        }

       public static int UpdateOrdertoSetPrice(int order_id ,string notes, float total_price)
        {
            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(connectionString);
            string query = "Update  Orders set total_price = @total_price, notes =@notes where"+ 
               " order_id=@order_id;" ;
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@order_id", order_id);
            command.Parameters.AddWithValue("@notes", notes);
            command.Parameters.AddWithValue("@total_price", total_price);
            try
            {
                connection.Open();
               rowsAffected = command.ExecuteNonQuery();
               

            }
            catch (Exception ex) { connection.Close(); }finally { connection.Close(); }
            return rowsAffected;
        }


        public static bool GetOrderitemsInfoById(int order_items_id,int order_id,ref float price,ref string notes,ref int quantity) 
        {
            bool isFound = false;
            SqlConnection connection =  new SqlConnection(connectionString);
            string query = "Select * form OrderItems where order_id = @order_id;  ";
            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    order_items_id = (int)reader["order_item_id"];
                    order_id = (int)reader["order_id"];
                    price = (float)reader["unit_price"];
                    quantity = (int)reader["quantity"];

                    
                }

                reader.Close();


            }catch (Exception ex) { connection.Close(); } finally { connection.Close(); }
            return isFound;

        }
        public static bool UpdateProductStock(int product_id, int quantity)
        {
            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(connectionString);

            // Subtract the ordered quantity from stock
            string query = @"UPDATE Products 
                    SET stock = stock - @quantity 
                    WHERE product_id = @product_id AND stock >= @quantity";

            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@product_id", product_id);
            command.Parameters.AddWithValue("@quantity", quantity);

            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Log the error if needed
                Console.WriteLine("Error updating stock: " + ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }

            return rowsAffected > 0;
        }


        public static int GetTodayOrdersCount()
        {
            int count = 0;
            SqlConnection connection = new SqlConnection(connectionString);

            string query = @"
        SELECT COUNT(*) 
        FROM Orders
        WHERE CAST(date_of_order AS DATE) = CAST(GETDATE() AS DATE);
    ";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    count = Convert.ToInt32(result);
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                connection.Close();
            }

            return count;
        }


        public static float GetTodaySalesTotal()
        {
            float totalSales = 0;
            SqlConnection connection = new SqlConnection(connectionString);

            string query = @"
        SELECT ISNULL(SUM(total_price), 0)
        FROM Orders
        WHERE CAST(date_of_order AS DATE) = CAST(GETDATE() AS DATE);
    ";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && float.TryParse(result.ToString(), out float value))
                {
                    totalSales = value;
                }
            }
            catch (Exception ex)
            {
            }
            finally
            {
                connection.Close();
            }

            return totalSales;
        }



    }

}
