﻿using System;
using OrderDataAccessLayer;

namespace OrderBusinessAccessLayer
{
    public class clsOrderBusinessLayer
    {

        private int order_item_id { get; set; }
        private int order_id { get; set; }
        private int quantity { get; set; }
        private float unit_price { get; set; }
        private float subtotal { get; set; }
        private int product_id { get; set; }
        private string notes { get; set; }
        private string type_of_payment { get; set; }
        private float totalPrice    { get; set; }
        private DateTime date_of_order { get; set; }
        private int campus_id { get; set; }
         
        public clsOrderBusinessLayer(int order_item_id,int order_id,float unitprice,int quantity) {
            this.unit_price = unitprice;
            this.order_id = order_id;
            this.quantity = quantity;
            this.order_item_id=order_item_id;

        }
        public static int _AddNewOrder(DateTime date_of_order,string notes,float total_price,
            string type_of_payment,int campus_id)
        {
            return clsOrderDataAccessLayer.AddNewOrder(date_of_order, notes, type_of_payment, total_price
                , campus_id)  ;

        }

        public static int _addToOrderItems(int order_id,int product_id,float unit_price,int quantity)
        {
            if(
                clsOrderDataAccessLayer.UpdateProductStock(product_id, quantity))
            {
                return clsOrderDataAccessLayer._AddNewOrderItems(order_id, product_id, unit_price, quantity);
              
                
            }
            return 0;
           

        }

        public static bool UpdateOrder(int id ,float price, string notes)
        {
             return clsOrderDataAccessLayer.UpdateOrdertoSetPrice(id,notes,price)> 0;
        }


        public static int GetnbTodayOrders()
        {
            return clsOrderDataAccessLayer.GetTodayOrdersCount();
        }

       public static float GetTodaySales()
        {
            return clsOrderDataAccessLayer.GetTodaySalesTotal();
        }

    }
}
