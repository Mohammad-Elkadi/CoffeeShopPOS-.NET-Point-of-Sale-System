﻿using System;

using System.Data.SqlClient;

using System.Data;


public class clsUsersDataAccessLayer
{
    public static string connectionString = "Server=LAPTOP-U3G4VRD6\\MYSQLSERVER1;Database=CoffeeShopDB;Integrated Security=True;";
    public static bool GetUserInfo(int ID, string Password,ref string firstName,ref string lastname,ref string phone,ref string address,
     ref   string role,ref DateTime d,ref int campusid)
    {
        bool isfound = false;
        SqlConnection connection = new SqlConnection(connectionString);
            string query = "Select *from Users where ID=@ID AND Password=@Password"; 
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@ID", ID);
        command.Parameters.AddWithValue("@Password", Password);
        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isfound = true;

                firstName = reader["FirstName"] == DBNull.Value ? "" : (string)reader["FirstName"];
                lastname = reader["LastName"] == DBNull.Value ? "" : (string)reader["LastName"];
                role = reader["Role"] == DBNull.Value ? "" : (string)reader["Role"];
                campusid = reader["CampusID"] == DBNull.Value ? 1 : (int)reader["CampusID"];
                phone = reader["Phone"] == DBNull.Value ? "" : (string)reader["Phone"];
                address = reader["Address"] == DBNull.Value ? "" : (string)reader["Address"];
                d = reader["DateofBirth"] == DBNull.Value ? DateTime.Now : (DateTime)reader["DateofBirth"];
            }
        
            reader.Close();
            
        }
        catch (Exception ex) { isfound = false; }
        finally { connection.Close(); }

        return isfound;
            
            
            
           
           
    }
    


}


