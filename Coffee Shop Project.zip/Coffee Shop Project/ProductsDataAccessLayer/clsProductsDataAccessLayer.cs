﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;


namespace ProductsDataAccessLayer
{
    public class clsProductsDataAccessLayer
    {
        public static string connectionString = "Server=LAPTOP-U3G4VRD6\\MYSQLSERVER1;Database=CoffeeShopDB;Integrated Security=True;";

        public static DataTable _GetAllProducts()
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(connectionString);
            string query = @"
                    SELECT  
                        p.product_id,  
                        p.name AS product_name,  
                        p.is_available,
                        p.description,
                        p.Stock,

                        p.price,  
                        c.name AS category_name  
                    FROM Products p  
                    LEFT JOIN Category c ON p.category_id = c.category_id;";

            SqlCommand command = new SqlCommand(query, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {

                    dt.Load(reader);

                }
                reader.Close();


            }
            catch (Exception ex) { connection.Close(); }
            finally { connection.Close(); }
            return dt;
        }

        public static int GetProductsCount()
        {
            int isAvailable = 1;
            SqlConnection connection = new SqlConnection(connectionString);
            int count = 0;
            string query = "SELECT COUNT(*) FROM Products where is_available = @isAvailable";
            SqlCommand command = new SqlCommand(@query, connection);
            command.Parameters.AddWithValue("@isAvailable", isAvailable);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    count = (int)result;


                }

            }
            catch (Exception ex) { connection.Close(); }
            finally { connection.Close(); }
            return count;

        }



        public static bool DeleteProduct(int Product_ID)
        {
            int rowAffected = 0;
            SqlConnection connection = new SqlConnection(connectionString);
            string query = "Delete from products where Product_ID=@Product_ID ";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Product_ID", Product_ID);
            try
            {
                connection.Open();
                rowAffected = command.ExecuteNonQuery();
            }
            catch (Exception ex) { connection.Close(); }
            finally { connection.Close(); }
            return rowAffected > 0;
        }

        
        public static int[] GetIDsForProducts()
        {
            DataTable de = new DataTable();
            int isAvailable = 1;
            SqlConnection connection = new SqlConnection(connectionString);
            string query = "Select product_ID from Products where is_available = @isAvailable";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@isAvailable", isAvailable);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                de.Load(reader);
                int[] IDs = new int[de.Rows.Count];
                for (int i = 0; i < de.Rows.Count; i++)
                {
                    IDs[i] = Convert.ToInt32(de.Rows[i]["product_id"]);


                }
                return IDs;

            }
            catch (Exception ex) { connection.Close(); }
            finally { connection.Close(); }
            return new int[0];



        }



        public static bool GetProductsByID(int id,ref string name ,ref string category_name ,ref float price,ref string desc,ref int stock,ref string QRCode)
        {
            bool isFound = false;
            int isAvailable = 1;

            SqlConnection connection = new SqlConnection(connectionString);
            string query = @"
    SELECT 
        p.product_id, 
        p.name AS product_name,
        p.stock ,
        p.price,p.description,p.QRCode,
        c.name AS category_name
    FROM Products p
    LEFT JOIN Category c ON p.category_id = c.category_id
    WHERE p.product_id = @id";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@id", id);


            try
            {

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound =  true;
                    name = (string)reader["product_name"];
                    price = Convert.ToSingle(reader["price"]);
                    desc = (string)reader["description"];
                    stock = (int)reader["stock"];

                    category_name = (string)reader["category_name"].ToString();
                    QRCode = (string)reader["QRCode"];

                 


                }
                else
                {
                    isFound = false;
                }
                reader.Close();


            }
            catch (Exception ex) { connection.Close(); return isFound; }
            finally { connection.Close(); }
            return isFound;
            




        }
         
        public static int AddNewProduct(string name , int category_id,float price, string Description,
            int stock,string QRCode)
        {
            int ProductID = -1;
            bool is_available = stock > 0;



            SqlConnection connection = new SqlConnection(connectionString);
            string query = "Insert INTO Products (name,category_id,price,is_available,description,stock,QRCode) values(@name,@category_id," +
                "@price,@is_available , @Description,@stock,@QRCode);SELECT SCOPE_IDENTITY();";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@category_id", category_id);
            command.Parameters.AddWithValue("@price", price);
            command.Parameters.AddWithValue("@is_available", is_available);

            command.Parameters.AddWithValue("@Description", Description);
            command.Parameters.AddWithValue("@stock", stock);
            command.Parameters.AddWithValue("@QRCode", QRCode);
            try
            {
                connection.Open();
                object result = command.ExecuteScalar();
                
                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    ProductID = insertedID;
                }
            }
            catch {
                connection.Close(); }
            finally { connection.Close(); }
            return ProductID;

        }
        public static DataTable GetAllCategories()
        {
            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(connectionString);
            string query = "Select category_id, name from Category";
            SqlCommand command =  new SqlCommand(query,connection);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                dt.Load(reader);
                    
                
                reader.Close();


            }
            catch { connection.Close(); }
            finally { connection.Close(); }
            return dt;


        }

        public static bool UpdateProduct(int product_id , string name,  int category_id, float price, string Description, int stock, string QRCode)
        {
            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(connectionString);
            string query = @"Update Products set name =@name, category_id=@category_id , price = @price, description
                = @description, stock =@stock where product_id=@product_id";
            SqlCommand command =  new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@product_id",product_id);
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@category_id", category_id);
            command.Parameters.AddWithValue("@price", price);
            command.Parameters.AddWithValue("@description", Description);
            command.Parameters.AddWithValue("@stock", stock);
            command.Parameters.AddWithValue("@QRCode", QRCode);
            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();


            }
            catch { connection.Close(); }finally { connection.Close(); }
            return rowsAffected > 0;


        }

        public static bool AddStock(int product_id,int stockNb)
        {
            if (stockNb== 0 || stockNb < 0)
            {
                return false;
                
            }
            int is_Added  = 0;
            SqlConnection connection =  new SqlConnection (connectionString);

            string query = @"Update products set stock = stock + @stockNb where product_id=@product_id; ";
            SqlCommand command =  new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@product_id", product_id);
            command.Parameters.AddWithValue("@stockNb",stockNb);
            try
            {
                connection.Open();
                is_Added = command.ExecuteNonQuery();



            }
            catch { connection.Close(); } finally { connection.Close(); }
            return is_Added > 0;
            
        }

        public static DataTable GetProductsDataForInventory()
        {
            DataTable dt = new DataTable();
            SqlConnection connection =  new SqlConnection(connectionString);
            string query = @"
                    SELECT  
                        p.product_id,  
                        p.name AS product_name,  
                        p.is_available,
                       
                        p.Stock,

                        c.name AS category_name  
                    FROM Products p  
                    LEFT JOIN Category c ON p.category_id = c.category_id;";

            SqlCommand command =  new SqlCommand (query, connection);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                   
                if (reader.HasRows)
                {
                    dt.Load(reader);
                    
                }
                reader.Close();

            }
            catch { connection.Close(); } finally { connection.Close(); }
            return dt;

        }

    }
     
}
