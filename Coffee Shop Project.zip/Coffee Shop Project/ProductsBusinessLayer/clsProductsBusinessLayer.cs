﻿using ProductsDataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;


namespace ProductsBusinessLayer
{
    public class clsProductsBusinessLayer
    {
       
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string CategoryName {  get; set; }
        public int CategoryID { get; set; }
        public float productPrice {  get; set; }
         public string desc {  get; set; }
        public int stock {  get; set; }
        public string QRCode {  get; set; }

        public bool isAvailable {  get; set; }

        public clsProductsBusinessLayer(int ProductID,string productName,
            string categoryName,int categoryID,float productPrice,bool isAvailable)
        {
            this.ProductID = ProductID;
            this.ProductName = productName;
            this.CategoryName = categoryName;
            this.CategoryID = categoryID;
            this.productPrice=productPrice;
            this.isAvailable = isAvailable;

        }

        public clsProductsBusinessLayer(int ProductID, string productName,
            string CategoryName,  float productPrice, string desc, int stock,string QRCode)
        {
            this.ProductID = ProductID;
            this.ProductName = productName;
            this.stock = stock;
            this.CategoryName = CategoryName;
            this.desc= desc;
            this.productPrice = productPrice;
            this.QRCode = QRCode;
           

        }

        public static DataTable GetAllProducts()
        {
            return clsProductsDataAccessLayer._GetAllProducts();


        }
        public static int _getProductsNumber()
        {
            return clsProductsDataAccessLayer.GetProductsCount();

        }

        public static DataTable GetAllProductsForInvenotry()
        {
            return clsProductsDataAccessLayer.GetProductsDataForInventory();
        }

        public static clsProductsBusinessLayer GetProducInfotByID(int Id)
        {
            string name = "", category_name = "" , desc = "";
            float price = 0;int stock = 0;string qrCode = "";
            if (clsProductsDataAccessLayer.GetProductsByID(Id, ref name, ref category_name, ref price,ref desc,ref stock,ref qrCode))
            {
                return new clsProductsBusinessLayer(Id, name, category_name, price,desc,stock,qrCode);
            }

            return null;



        }
        public static int[]GetProductsByArray()
        {
            return clsProductsDataAccessLayer.GetIDsForProducts();

        }

        public static bool _DeleteProductbyID(int id)
        {
            if (clsProductsDataAccessLayer.DeleteProduct(id))
            {

                return true;
            }
            return false;
        }

        public static bool _AddNewProduct(string name,int category_id, float price,string desc
            ,int stock, string QRCode)
        {

            return clsProductsDataAccessLayer.AddNewProduct(name, category_id, price, desc, stock, QRCode) >0;
        }

        public static DataTable _GetAllCatergoriesName()
        {
            return clsProductsDataAccessLayer.GetAllCategories();
        }

        public static bool _UpdateProduct(int id,string name, int category_id,float price,string desc
           ,int stock,string QRCode)
        {
            

          return clsProductsDataAccessLayer.UpdateProduct(id,name, category_id, price, desc,stock, QRCode) ;

        }

        public static bool _Add_To_Inventory(int id,int amount)
        {
            return clsProductsDataAccessLayer.AddStock(id,amount);  
        }

        





    }
}
